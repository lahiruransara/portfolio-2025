2025 Portfolio v3
